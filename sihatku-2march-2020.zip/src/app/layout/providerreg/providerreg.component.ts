import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-providerreg',
  templateUrl: './providerreg.component.html',
  styleUrls: ['./providerreg.component.scss']
})
export class ProviderregComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
