import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-procedures-details',
  templateUrl: './my-procedures-details.component.html',
  styleUrls: ['./my-procedures-details.component.scss']
})
export class MyProceduresDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
