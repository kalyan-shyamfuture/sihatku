import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-procedures-edit',
  templateUrl: './my-procedures-edit.component.html',
  styleUrls: ['./my-procedures-edit.component.scss']
})
export class MyProceduresEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
