import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-provider',
  templateUrl: './footer-provider.component.html',
  styleUrls: ['./footer-provider.component.scss']
})
export class FooterProviderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
