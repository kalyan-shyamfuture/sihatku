export const environment = {
  production: true,
  apiEndpoint: "https://mucapp.azurewebsites.net/api/",
  imageEndpoint: "https://mucapp.azurewebsites.net"
};
