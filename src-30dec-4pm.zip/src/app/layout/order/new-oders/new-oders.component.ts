import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-oders',
  templateUrl: './new-oders.component.html',
  styleUrls: ['./new-oders.component.scss']
})
export class NewOdersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
