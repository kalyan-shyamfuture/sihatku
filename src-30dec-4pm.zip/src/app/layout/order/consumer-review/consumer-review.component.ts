import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-consumer-review',
  templateUrl: './consumer-review.component.html',
  styleUrls: ['./consumer-review.component.scss']
})
export class ConsumerReviewComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
