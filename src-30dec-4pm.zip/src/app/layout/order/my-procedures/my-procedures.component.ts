import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-procedures',
  templateUrl: './my-procedures.component.html',
  styleUrls: ['./my-procedures.component.scss']
})
export class MyProceduresComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
