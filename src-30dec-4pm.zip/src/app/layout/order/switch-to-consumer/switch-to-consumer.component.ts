import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-switch-to-consumer',
  templateUrl: './switch-to-consumer.component.html',
  styleUrls: ['./switch-to-consumer.component.scss']
})
export class SwitchToConsumerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
