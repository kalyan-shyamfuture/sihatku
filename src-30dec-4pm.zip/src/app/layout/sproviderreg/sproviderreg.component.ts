import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder ,Validators , FormArray} from '@angular/forms';
import { PasswordValidation } from '../../core/validation/PasswordValidation';
import {  MainService} from "../../core/services/main.service";
import { UserService } from "../../core/services/user.service";
import { FormControlValidator } from "../../core/validation/form-control.validator";
@Component({
  selector: 'app-sproviderreg',
  templateUrl: './sproviderreg.component.html',
  styleUrls: ['./sproviderreg.component.scss']
})
export class SproviderregComponent implements OnInit {
  public centerLogo: any;
  public practionarLogo:any;
  public proImage:any=[];
  fileDataCenterLogo:any;
  practionerImage:any;
  fileDataProfile:any;
  imgPractURL:any;
  imgCenterURL:any;
  serviceRegForm: FormGroup;
  submitted: boolean = false;
  services_details: FormArray;
  practioner_details: FormArray;
  myForm: FormGroup;
  listSpeciality:any =[];
  listProcedure:any=[];
  listTitle:any = [
    {
      "id":1,
      "name":"Mr"
    },
    {
      "id":2,
      "name":"Mrs"
    }

  ];
  listGender:any = [
    {
      "id":1,
      "name":"Male"
    },
    {
      "id":2,
      "name":"Female"
    }

  ];
  listCountry:any=[];

  listfieldSpeciality:any=[
    {
      "id":1,
      "name":"Speciality 1"
    },
    {
      "id":2,
      "name":"Speciality 2"
    },
    {
      "id":3,
      "name":"Speciality 3"
    },
    {
      "id":4,
      "name":"Speciality 4"
    }
  ];

  constructor(
    private formBuilder: FormBuilder,
    public mainService:MainService,
    public userService:UserService
  ) { 
    
  }

  ngOnInit() {
      this.serviceRegForm = this.formBuilder.group({
        email: ['k@k.com', [Validators.required, Validators.email]],
        password: ['12345678 ', [Validators.required, Validators.minLength(6)]],
        confirmPassword: ['12345678', [Validators.required]],
        clinicName: ['Test Clinic', [Validators.required]],
        aboutClinic: ['This is about the clinic', [Validators.required]],
        providerType:['1'],
        services_details: this.formBuilder.array([ this.servicecreate() ]),
      }, {
        validator: PasswordValidation.MatchPassword
      })

    this.getSpeiality();
   // this.getProcedure();
    this.getCountry();

  }

  errorState(field, validatorFieldName) {
    return FormControlValidator(field, validatorFieldName);
  }

  getSpeiality() {
    this.mainService.getSpecialityList().subscribe(
      res => {
        console.log("Speciality List==>",res);
        this.listSpeciality = res['response']
        console.log("List Speciality ==>",this.listSpeciality);
      },
      error => {
        console.log(error.error);
       
      }
    )
    
  }

  getProcedure(event) {
    console.log(event.value);
    this.mainService.getProcedurebySpeciality(event.value).subscribe(
      res => {
        console.log("Speciality List==>",res);
        this.listProcedure = res['response']
        console.log("List Procedure ==>",this.listProcedure);
      },
      error => {
        console.log(error.error);
       
      }
    )
  }

  getCountry() {
    this.mainService.getCountryList().subscribe(
      res => {
        console.log("Country List==>",res);
        this.listCountry = res['response']
        console.log("List Country ==>",this.listCountry);
      },
      error => {
        console.log(error.error);
       
      }
    )
  }

  get f() { return this.serviceRegForm.controls; }

  servicecreate(): FormGroup {
    return this.formBuilder.group({
      speciality:['1', Validators.required],
      aboutProcedure: ['This is about procedure', Validators.required],
      setPromoCode: ['zzz123', Validators.required],
      selectProcedure:['', Validators.required],
      setPriceUsa: ['10', Validators.required],
      setPriceMalaysia: ['100', Validators.required],
      discount:['10', Validators.required],
      practioner_details: this.formBuilder.array([ this.practionercreate() ])
    });
  }

  serviceaddItem(): void {
    this.services_details = this.serviceRegForm.get('services_details') as FormArray;
    this.services_details.push(this.servicecreate());
    console.log(this.serviceRegForm);
  }



  practionercreate(): FormGroup{
    return this.formBuilder.group({
      firstName:['Kalyan ', Validators.required],
      lastName:['Acharya', Validators.required],
      passportNumber: ['123456', Validators.required],
      gender: ['1', Validators.required],
      fieldSpeciality: ['', Validators.required],
     // placeofPractice:['', Validators.required],
      medicalCouncilNo:['5655676', Validators.required],
      medicalSchool: ['aaaaaaa', Validators.required],
      title:['1', Validators.required],
      country: ['1', Validators.required],
      contactNumber:['7894561230', Validators.required],
      expertiseCategory: ['', Validators.required],
      addressPractice:['Kolkata', Validators.required],
      registrationNo: ['9999999', Validators.required],
      aboutPractioner: ['This is about practioner', Validators.required],
      dob: ['', Validators.required],
      pracsubCategory: ['1', Validators.required],
      practisingSince: ['2010', Validators.required],
      qualification: ['MBBS', Validators.required],
    });
  }
  practioneraddItem(index): void {
    console.log(index); 
    this.services_details = this.serviceRegForm.get('services_details') as FormArray;
    const practitionerForm = this.services_details.at(index).get('practioner_details') as FormArray;
    practitionerForm.push(this.practionercreate());
    console.log(this.serviceRegForm);
  }


  deleteServices(servicesIndex){
    this.services_details.removeAt(servicesIndex);
  }

  deletePractioner(servicesIndex,practionerIndex){
   const serviceForm = this.services_details.at(servicesIndex).get('practioner_details') as FormArray;
   serviceForm.removeAt(practionerIndex);
  }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.serviceRegForm.invalid) {
      console.log("Form Invalid");
      return;
    }

    else {
      console.log("Form is valid");
      console.log(this.serviceRegForm.value);
      console.log(JSON.stringify(this.serviceRegForm.value))

    }
  }

    /* Handle form errors in Angular 8 */
    public errorHandling = (form: FormGroup,control: string, error: string) => {
      return form.controls[control].hasError(error);
    }

    // centerLogoUpload(event) {
    //     if (event.target.files.length) {
    //       this.centerLogo = event.target.files[0];
    //     //  console.log(this.centerLogo);
    //     }

    //     if (event.target.files.length) {
    //       this.centerLogo = event.target.files[0];
    //       console.log(this.centerLogo);
    //       var reader = new FileReader();
    //       reader.readAsDataURL(event.target.files[0]); 
    //       reader.onload = (_event) => { 
    //         this.imgCenterURL = reader.result; 
    //         console.log(this.imgCenterURL);
    //       }
    //     }
    // }

    centerLogoUpload(event) {
      if (event.target.files.length) {
        this.centerLogo = event.target.files[0];
      this.fileDataCenterLogo = <File>event.target.files[0];
      const formData = new FormData();
      formData.append('ImageUpload', this.fileDataCenterLogo, this.fileDataCenterLogo.name);
      this.mainService.uploadImage(formData).subscribe(
        res => {
          console.log("Center Logo Upload==>",res);
        },
        error => {
         
        }
      )
      }
  }

  practionarImageUpload(event) {
    if (event.target.files.length) {
      this.practionerImage = event.target.files[0];
    this.fileDataProfile = <File>event.target.files[0];
    const formData = new FormData();
    formData.append('ImageUpload', this.practionerImage, this.practionerImage.name);
    this.mainService.uploadImage(formData).subscribe(
      res => {
        console.log("Practioner Image Upload==>",res);
      },
      error => {
       
      }
    )
    }
}

    procedureImageUpload(event) {
      console.log(event.target.files.length);
     // this.proImage = [];
      for(var i = 0; i < event.target.files.length; i++ ) {
          this.proImage.push(event.target.files[i]);
      }
      console.log(this.proImage);
    
    }

    // practionarImageUpload(event) {
    //   if (event.target.files.length) {
    //     this.practionarLogo = event.target.files[0];
    //     console.log(this.centerLogo);
    //     var reader = new FileReader();
    //     reader.readAsDataURL(event.target.files[0]); 
    //     reader.onload = (_event) => { 
    //       this.imgPractURL = reader.result; 
    //       console.log(this.imgPractURL);
    //     }
    //   }
    // }

    submitForm() {
      console.log(this.serviceRegForm.value)
      this.serviceRegForm.markAllAsTouched();
      const formValue = [this.serviceRegForm.value];
   //   let formData = new FormData();
     // formData.append('servicedetails[].name', this.serviceRegForm.value.name);
     // formData.append('servicedetails[].name', this.serviceRegForm.value.name);
    // formData.append('email', this.serviceRegForm.value.email);
    // console.log(formData);
     this.userService.serviceProRegister(formValue).subscribe(
      res => {
        console.log("Country List==>",res);
        this.listCountry = res['response']
       // console.log("List Country ==>",this.listCountry);
      },
      error => {
        console.log(error.error);
       
      }
    )
    }




}
