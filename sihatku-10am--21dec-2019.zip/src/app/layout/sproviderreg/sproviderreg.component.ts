import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder ,Validators , FormArray} from '@angular/forms';

@Component({
  selector: 'app-sproviderreg',
  templateUrl: './sproviderreg.component.html',
  styleUrls: ['./sproviderreg.component.scss']
})
export class SproviderregComponent implements OnInit {

  serviceRegForm: FormGroup;
  submitted: boolean = false;
  services_details: FormArray;
  practioner_details: FormArray;
  myForm: FormGroup;
  constructor(
    private formBuilder: FormBuilder
  ) { }

  ngOnInit() {
    this.reactiveForm()
    this.serviceRegForm = this.formBuilder.group({
      email:['test@test.com', [Validators.required]],
      password:['12345678', [Validators.required]],
      confPass:['12345678', [Validators.required]],
      clinicName:['Test1', [Validators.required]],
      aboutClinic:['Test2', [Validators.required]],
      providerType:['1'],
     services_details: this.formBuilder.array([ this.servicecreate() ]),
    })
  }

  get f() { return this.serviceRegForm.controls; }

  servicecreate(): FormGroup {
    return this.formBuilder.group({
      speciality:['1'],
      aboutProcedure: ['testtttt'],
      setPromoCode: ['ABC100 '],
      selectProcedure:['1'],
      setPrice: ['1'],
      discount:['1'],
      practioner_details: this.formBuilder.array([ this.practionercreate() ])
    });
  }

  serviceaddItem(): void {
    this.services_details = this.serviceRegForm.get('services_details') as FormArray;
    this.services_details.push(this.servicecreate());
    console.log(this.serviceRegForm);
  }



  practionercreate(): FormGroup{
    return this.formBuilder.group({
      fullName:['fghgfhgf'],
      passportNumber: ['gfhghgh'],
      gender: ['1'],
      pspeciality: ['1'],
      placeofPractice: ['tttt'],
      medicalCouncilNo:['465654'],
      medicalSchool: ['dfbdfhf'],
      utitle:['1'],
      countryResidence: ['2'],
      contactNumber:['99999999'],
      expertiseCategory: ['1'],
      addressPractice:['gdfgdf'],
      registrationNo: ['fbhb45767'],
      aboutPractioner: ['hgjhgjhjhgjh'],
      dob: [''],
      pracsubCategory: ['dsfdsf'],
      practisingSince: ['fgdfg'],
      qualification: ['dfdf']
    });
  }
  practioneraddItem(index): void {
    console.log(index); 
    this.services_details = this.serviceRegForm.get('services_details') as FormArray;
    const practitionerForm = this.services_details.at(index).get('practioner_details') as FormArray;
    practitionerForm.push(this.practionercreate());
    console.log(this.serviceRegForm);
  }


  deleteServices(servicesIndex){
    this.services_details.removeAt(servicesIndex);
  }

  deletePractioner(servicesIndex,practionerIndex){
   const serviceForm = this.services_details.at(servicesIndex).get('practioner_details') as FormArray;
   serviceForm.removeAt(practionerIndex);
  }

  onSubmit() {
    this.submitted = true;
    // stop here if form is invalid
    if (this.serviceRegForm.invalid) {
      console.log("Form Invalid");
      return;
    }

    else {
      console.log("Form is valid");
      console.log(this.serviceRegForm.value);
      console.log(JSON.stringify(this.serviceRegForm.value))

    }
  }


  reactiveForm() {
    this.myForm = this.formBuilder.group({
      name: ['', [Validators.required]],
    })
  }

  /* Date */
    date(e) {
      var convertDate = new Date(e.target.value).toISOString().substring(0, 10);
      this.myForm.get('dob').setValue(convertDate, {
        onlyself: true
      })
    }

    /* Handle form errors in Angular 8 */
    public errorHandling = (control: string, error: string) => {
      return this.myForm.controls[control].hasError(error);
    }


}
