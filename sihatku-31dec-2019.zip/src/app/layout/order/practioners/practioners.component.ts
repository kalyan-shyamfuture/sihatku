import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-practioners',
  templateUrl: './practioners.component.html',
  styleUrls: ['./practioners.component.scss']
})
export class PractionersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
