import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-explore-sihatku',
  templateUrl: './explore-sihatku.component.html',
  styleUrls: ['./explore-sihatku.component.scss']
})
export class ExploreSihatkuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
