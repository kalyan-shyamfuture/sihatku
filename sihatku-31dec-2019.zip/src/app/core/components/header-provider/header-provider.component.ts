import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-provider',
  templateUrl: './header-provider.component.html',
  styleUrls: ['./header-provider.component.scss']
})
export class HeaderProviderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
