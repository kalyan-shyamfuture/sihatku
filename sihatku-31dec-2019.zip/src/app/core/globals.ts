'use strict';
// export const pageSize: number =10;
export const itemPerPage: number = 10;
export const paginationMaxSize: number=3;   